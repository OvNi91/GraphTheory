This is our Graph Theory Project
It was made by group B2, composed of :
-> GARNIER Aurélien
-> ROYER Médéric
-> MAZARDIN Grégoire

In the "src" folder, you'll find our our source code
In the "txt" folder, you'll find the graphs in the format asked

- The file "Main.java" contains the executable program for all the project
- The file "Graph.java" contains the "Graph" class, with all methods
  concerning the entire graph
- The file "Vertex.java" contains the "Vertex" class, with the data structure
  of the vertices and their attributes
- The file "Edge.java" contains the "Edge" class, with the data structure 
  of the edges and their attributes

If you have any feedback to give us, feel free to send a mail at 
gregoire.mazardin@efrei.net or mederic.royer@efrei.net or aurelien.garnier@efrei.net

Thank you for the time reading this file and checking our work ! 

Have a nice day ! 